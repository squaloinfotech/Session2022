-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2021 at 09:03 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rail`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `email` varchar(50) NOT NULL,
  `passwor` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`email`, `passwor`) VALUES
('admin@rail.com', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `orderid` varchar(10) NOT NULL,
  `trainno` varchar(120) NOT NULL,
  `uemail` varchar(500) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `noofseat` int(100) NOT NULL,
  `froms` varchar(200) NOT NULL,
  `tos` varchar(100) NOT NULL,
  `fare` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`orderid`, `trainno`, `uemail`, `uname`, `noofseat`, `froms`, `tos`, `fare`) VALUES
('23277', '10041', 'abc@mail.com', 'abc', 5, 'London', 'York', '2650'),
('40778', '1001', 'abc@mail.com', 'abc', 2, 'London', 'Liverpool', '50'),
('19958', '1018', 'abc@mail.com', 'abc', 2, 'Manchester', 'London', '50');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `email` varchar(100) NOT NULL,
  `password` int(50) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`email`, `password`, `name`) VALUES
('abc@mail.com', 123, 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `trainno` varchar(100) NOT NULL,
  `trainname` varchar(200) NOT NULL,
  `rate` int(120) NOT NULL,
  `date` date NOT NULL,
  `froms` varchar(200) NOT NULL,
  `tos` varchar(200) NOT NULL,
  `seats` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`trainno`, `trainname`, `rate`, `date`, `froms`, `tos`, `seats`) VALUES
('1001', 'Cambrian Coast Express', 25, '2021-08-11', 'London', 'Liverpool', 23),
('10024', 'Cambrian Coast Express', 20, '2021-08-13', 'London', 'Manchester', 22),
('10025', 'Cambrian Coast Express', 16, '2021-08-17', 'London', 'York', 29),
('10031', 'Cambrian Coast Express', 16, '2021-08-12', 'London', 'Sheffield', 29),
('1011', 'Caledonian Sleeper', 25, '2021-08-14', 'Liverpool', 'London', 20),
('10024', 'Caledonian Sleeper', 12, '2021-08-15', 'Liverpool', 'Manchester', 15),
('10045', 'Caledonian Sleeper', 30, '2021-08-27', 'Liverpool', 'York', 27),
('10431', 'Caledonian Sleeper', 16, '2021-08-30', 'Liverpool', 'Sheffield', 23),
('1018', 'East Anglian', 25, '2021-08-16', 'Manchester', 'London', 20),
('1004', 'East Anglian', 12, '2021-08-25', 'Manchester', 'Liverpool', 17),
('10045', 'East Anglian', 30, '2021-09-16', 'Manchester', 'York', 27),
('10431', 'East Anglian', 16, '2021-08-31', 'Manchester', 'Sheffield', 36),
('1011', 'Flying Scotsman', 37, '2021-08-18', 'York', 'London', 20),
('10824', 'Flying Scotsman', 20, '2021-09-01', 'York', 'Manchester', 19),
('10045', 'Flying Scotsman', 30, '2021-08-29', 'York', 'Liverpool', 27),
('10431', 'Caledonian Sleeper', 21, '2021-08-30', 'York', 'Sheffield', 76),
('1011', 'Lakes Express', 25, '2021-08-28', 'Sheffield', 'London', 11),
('10024', 'Lakes Express', 30, '2021-09-15', 'Sheffield', 'Manchester', 15),
('10045', 'Lakes Express', 10, '2021-08-27', 'Sheffield', 'York', 27),
('10431', 'Lakes Express', 16, '2021-08-20', 'Sheffield', 'Liverpool', 23),
('100257', 'Inter City', 24, '2021-08-22', 'Liverpool', 'Sheffield', 78);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mobile` int(11) NOT NULL,
  `addr` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `email`, `dob`, `gender`, `mobile`, `addr`) VALUES
('abc', 'abc@mail.com', '2021-05-06', 'Male', 1234567890, 'london');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
