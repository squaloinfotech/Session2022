# Train_ticket_system
web-based application using Java Netbeans 
Install netbeans - IDE for java code (https://mirrors.estointernet.in/apache/netbeans/netbeans/12.4/Apache-NetBeans-12.4-bin-windows-x64.exe)
Install JDK - contains all supported files for java (https://download.oracle.com/otn-pub/java/jdk/16.0.1+9/7147401fd7354114ac51ef3e1328291f/jdk-16.0.1_windows-x64_bin.exe?AuthParam=1626414726_049795ff8c551f2633407c432fe154a7
)
Install tomcat server - It is a server where IDE runs (32-bit/64-bit Windows Service Installer)
Install Xampp - (https://downloadsapachefriends.global.ssl.fastly.net/7.3.29/xampp-windows-x64-7.3.29-0-VC15-installer.exe?from_af=true)
1) start tomcat
2) start MySQL
3) Open xampp and start apache and mysql 
4) click on admin of mysql to open localhost/phpmyadmin
import rail.sql (craete a database in phpmyadmin and import rail.sql)
open netbeans -  import train ticket system
Go to projects (left side) -> libraries -> import MySQLDriver - https://dev.mysql.com/downloads/file/?id=505212
-> import mysql-connector-java-8.0.24.jar
-> import JDK 15
-> import Apache Tomcat or TomEE
run the project

