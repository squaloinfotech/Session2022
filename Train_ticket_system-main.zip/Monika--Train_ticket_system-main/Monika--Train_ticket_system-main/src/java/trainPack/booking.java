
package trainPack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class booking extends HttpServlet {
public String bflag;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet booking</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet booking at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter p  = response.getWriter();
            String froms = request.getParameter("froms");
            String tos = request.getParameter("tos");
            String date = request.getParameter("tdate");
            String adlt = request.getParameter("adult");
            String chd = request.getParameter("child");
             int seat = 0;
             int rate = 0;
             int fare = 0;
             String uemail = request.getSession().getAttribute("email").toString();
             String uname = request.getSession().getAttribute("username").toString();
        Random rand = new Random();
        int x = rand.nextInt(50000)+1;
        String id = String.valueOf(x);
        String trainn ;
        int totals =0;
                    try{
         Class.forName("com.mysql.jdbc.Driver");
            
            Connection con;
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rail","root","");
            
            if (con == null) {
 
            }
            PreparedStatement psmt;
            psmt = con.prepareStatement("select * from train where froms='" + froms + "' and tos = '" + tos + "' and date = '" + date + "'");
            ResultSet rslt;       
            rslt = psmt.executeQuery();
            
            
            
             if (rslt.next() != false) {
                seat = Integer.parseInt(rslt.getString(7));
                rate = Integer.parseInt(rslt.getString(3));
                fare = (Integer.parseInt(adlt)+Integer.parseInt(chd))*rate;
                trainn = rslt.getString(1);
                totals = (Integer.parseInt(adlt)+Integer.parseInt(chd));
                if(seat != 0){
                    bflag="Y";
                    
                        PreparedStatement psmt1;
            psmt1 = con.prepareStatement("insert into booking(orderid,trainno,uemail,uname,noofseat,froms,tos,fare) values (?,?,?,?,?,?,?,?)");  
            psmt1.setString(1,id);
            psmt1.setString(2,trainn);
            psmt1.setString(3,uemail);
            psmt1.setString(4,uname);
              psmt1.setString(5,String.valueOf(totals));
              psmt1.setString(6,froms);
              psmt1.setString(7,tos);
              psmt1.setString(8,String.valueOf(fare));
              
              int i=psmt1.executeUpdate();  
                }
                else{
                    bflag="N2";
                }
                
            } else {
bflag="N1";
                
            }
    }catch(Exception ex){
        ex.printStackTrace();
    }
            
            if( bflag == "Y"){
                p.println("<script>alert('Train available and No. Seat available = "+seat+"');</script>");
                response.setContentType("text/html;charset=UTF-8");
            p.println("<html>");
          
          
       p.println("<Body style='margin:0;background-color:#2E64AE';>");
p.print("<br>");p.print("  <script src='Assets/JS/BookingValidation.js'></script>");
       p.println("<div id='main' style='width:80%;margin-left:10%;background-color:white';>");
       p.println("<br><div id='aa' style='height:10%'; ><font size='7' face='Baskerville Old Face' color='#2E64AE'><p>&nbsp;&nbsp;Online Rail Reservation System(Booking)</p></font></div>");
       p.println("");p.println("<hr>");
       p.print("<div class='row'>");
       p.print("<br><font size='5' face='Baskerville Old Face' ><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Final Payment = "+fare+"  Euro</b></font><br><br>");
        p.print("<form  method='POST' action='BookingDone.jsp'>");
             p.print("<div><font size='4' face='Baskerville Old Face' ><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gateway</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select id='to' style='width:25%;' onchange='alertCardType();'><option value='C'>Credit Card</option><option value='D'>Debit Card</option></select>");
       p.print("<br><br><div><font size='4' face='Baskerville Old Face' ><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enter Card Number</font></b>&nbsp;&nbsp;&nbsp;<input id='cn' style='width:25%;' maxLength='12' placeholder='Enter Card Number 12 digit' type='text'></div><br>");
       p.print("<div><font size='4' face='Baskerville Old Face' ><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CVC Number</font></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input style='width:25%;' class='form-control' name='cvc' maxLength='3' id='cvc' placeholder='CVC Code(3-digit number appers back side of card)' type='text'></div>");
       p.print("<div><br><div class='col-lg-2'></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button style='width:30%;' type='submit' class='btn-md btn-success' onclick='return paymentValidation();'>Pay</button></div></div><br><br><br>	");
       p.print("</div>");
      
       p.print("<div class='row'>");
        p.print("<div class='col-lg-1'>");
       p.print("</div>");
       p.print("<div class='col-lg-10'><center>");
   
 p.print("</div>");
       p.print("<div class='col-lg-1'>");
       p.print("</div>");
       
       
       
      
       p.print("</div>");
   
       p.println("</Body>");
       p.println("</html>");

            }else if( bflag == "N1"){
                 p.println("<script>alert('No Train available');window.location='UserHome.jsp';</script>");
            }else if( bflag == "N2"){
                 p.println("<script>alert('Train available But No. Seat available = "+seat+"');window.location='UserHome.jsp';</script>");
            }
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }
    public void checkBooking(String froms, String tos, String date) {
        

        
    }
}
