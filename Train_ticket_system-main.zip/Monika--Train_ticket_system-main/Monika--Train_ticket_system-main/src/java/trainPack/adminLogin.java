
package trainPack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class adminLogin extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /*
             * TODO output your page here. You may use following sample code.
             */
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet adminLogin</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet adminLogin at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

   


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter p  = response.getWriter();
        
                String email = request.getParameter("username");
                
                String password = request.getParameter("pass");
        
                PrintWriter out1 = response.getWriter();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection con;
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rail","root","");
            
            
            if (con == null) {
    //          return false;
            }


            PreparedStatement psmt;
            
            psmt = con.prepareStatement("select email ,passwor  from adminlogin  where email='" + email + "' and passwor = '" + password + "'");
            
            
            ResultSet rslt;       
            
           
            rslt = psmt.executeQuery();
            
            String user = "admin";
            if (rslt.next() != false) {
            
                HttpSession sess = request.getSession();
                request.setAttribute("username", "adminHome.jsp");
                
                
             
//                p.println("");
//                p.println("<script>alert('Login Sucsessfull');window.location='index.jsp';</script>");
                response.sendRedirect("adminHome.jsp");
                
                
            } else {

                p.println("<script>alert('Wrong username and password');window.location='adminLogin.jsp';</script>");
            }



        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex);
        }
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
