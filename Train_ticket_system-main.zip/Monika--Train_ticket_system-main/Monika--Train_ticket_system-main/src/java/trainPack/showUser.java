
package trainPack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class showUser extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet showUser</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet showUser at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                      PrintWriter p = response.getWriter();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection con;
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rail","root","");
            
            if (con == null) {
//            return false;
            }


            
            
        
           
            PreparedStatement psmt;
            psmt = con.prepareStatement("select * from user");
            ResultSet rslt;       
            rslt = psmt.executeQuery();
            
      
                   response.setContentType("text/html;charset=UTF-8");
            p.println("<html>");
            p.println("<link rel='stylesheet' href='Assets/bootstrap-3.3.5-dist/css/bootstrap.css'> ");
              p.println("<link rel='stylesheet' href='Assets/bootstrap-3.3.5-dist/css/bootstrap.min.css'> ");
              
       p.println("<Body style='margin:0;background-color:#2E64AE';>");
       
       p.println("<div id='main' style='width:80%;margin-left:10%;background-color:white';>");
       p.println("<br><div id='aa' style='height:10%'; ><font size='7' face='Baskerville Old Face' color='#2E64AE'><p>&nbsp;&nbsp;Online Rail Reservation System(Admin)</p></font></div>");
       p.println("");p.println("<hr>");
       p.print("<div class='row'>");
       p.print("<br><a style='text-decoration: none;' href=adminHome.jsp>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Back</a><br>");
       p.print("</div>");
      
       p.print("<div class='row'>");
        p.print("<div class='col-lg-1'>");
       p.print("</div>");
       p.print("<div class='col-lg-10'><center>");
    p.print("<table border=1 style='border-collapse: collapse;'><tr>   <th>User Name</th>  <th>User Email</th>  <th>Date of Birth</th> <th>Gender</th><th>Mobile No.</th> <th>Address</th><th>Remove User</th></thead>");
            while (rslt.next() ) {
                                                                                                                                                                               
               p.print("<tr ><td>"+  rslt.getString(2)+"</td> <td>"+  rslt.getString(1)+"</td> <td>"+  rslt.getString(3)+"</td> <td>"+  rslt.getString(4)+"</td><td>"+  rslt.getString(5)+"</td><td>"+  rslt.getString(6)+"</td><td><form action='removeUser' method='post'><input type=hidden name='remove' value='"+rslt.getString(1)+"'><button style='background-color:#ccc; width:100%; height:100%;' type='submit'>Remove</button></form></td> </tr>");
               
                
            }
       
       p.print("</table><br>")     ;
 p.print("</div>");
       p.print("<div class='col-lg-1'>");
       p.print("</div>");
       
       
       
      
       p.print("</div>");
   
       p.println("</Body>");
       p.println("</html>");


        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
