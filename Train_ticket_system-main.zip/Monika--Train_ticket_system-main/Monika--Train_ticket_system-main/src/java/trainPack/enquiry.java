
package trainPack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class enquiry extends HttpServlet {
public String bflag;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet enquiry</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet enquiry at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          PrintWriter p  = response.getWriter();
            String froms = request.getParameter("froms");
            String tos = request.getParameter("tos");
            String date = request.getParameter("tdate");
                  int seat = 0;
                  try{
         Class.forName("com.mysql.jdbc.Driver");
            
            Connection con;
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rail","root","");
            
            if (con == null) {
 
            }
            PreparedStatement psmt;
            psmt = con.prepareStatement("select * from train where froms='" + froms + "' and tos = '" + tos + "' and date = '" + date + "'");
            ResultSet rslt;       
            rslt = psmt.executeQuery();
            
            
            
             if (rslt.next() != false) {
                seat = Integer.parseInt(rslt.getString(7));
            
                if(seat != 0){
                    bflag="Y";
          
                }
                else{
                    bflag="N2";
                }
                
            } else {
bflag="N1";
                
            }
    }catch(Exception ex){
        ex.printStackTrace();
    }
            if( bflag == "Y"){
                p.println("<script>alert('Train available and No. Seat available = "+seat+"');window.location='enquiry.jsp';</script>");
                
            }else if( bflag == "N1"){
                 p.println("<script>alert('No Train available');window.location='enquiry.jsp';</script>");
            }else if( bflag == "N2"){
                 p.println("<script>alert('Train available But No. Seat available = "+seat+"');window.location='enquiry.jsp';</script>");
            }
    }
    

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
