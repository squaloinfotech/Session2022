
package trainPack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class login extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet login</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet login at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                       PrintWriter p  = response.getWriter();
        
                String email = request.getParameter("username");
                
        String password = request.getParameter("pass");
        
        PrintWriter out1 = response.getWriter();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection con;
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rail","root","");
            
            if (con == null) {
//            return false;
            }


            PreparedStatement psmt;
            
            psmt = con.prepareStatement("select email ,password ,name from login  where email='" + email + "' and password = '" + password + "'");
            
            
            ResultSet rslt;       
            
           
            rslt = psmt.executeQuery();
            
            
            if (rslt.next() != false) {
            
                HttpSession sess = request.getSession();
                sess.setAttribute("email", rslt.getString(1));
                sess.setAttribute("username", rslt.getString(3));
                
//                p.println("");
//                p.println("<script>alert('Login Sucsessfull');window.location='index.jsp';</script>");
                response.sendRedirect("UserHome.jsp");
                
            } else {

                p.println("<script>alert('Wrong username and password');window.location='index.jsp';</script>");
            }



        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
