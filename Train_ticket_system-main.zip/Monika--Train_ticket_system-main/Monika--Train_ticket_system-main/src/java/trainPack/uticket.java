
package trainPack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
 



public class uticket extends HttpServlet {
 ResultSet rslt;   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet uticket</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet uticket at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                       PrintWriter p = response.getWriter();
                       String uemail = request.getSession().getAttribute("email").toString();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection con;
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rail","root",""); 
            
            if (con == null) {
//            return false;
            }

            PreparedStatement psmt;
            psmt = con.prepareStatement("select * from booking where uemail = '" + uemail + "' ");
            //ResultSet rslt;       
            rslt = psmt.executeQuery();
            
 
      
                   response.setContentType("text/html;charset=UTF-8");
            p.println("<html>");
            p.println("<link rel='stylesheet' href='Assets/bootstrap-3.3.5-dist/css/bootstrap.css'> ");
              p.println("<link rel='stylesheet' href='Assets/bootstrap-3.3.5-dist/css/bootstrap.min.css'> ");
       p.println("<Body style='margin:0;background-color:#2E64AE';>");
       
       p.println("<div id='main' style='width:80%;margin-left:10%;background-color:white';>");
       p.println("<br><div id='aa' style='height:10%'; ><font size='7' face='Baskerville Old Face' color='#2E64AE'><p>&nbsp;&nbsp;Online Rail Reservation System</p></font></div>");
       p.println("");p.println("<hr>");
       p.print("<div class='row'>");
       p.print("<br><a style='text-decoration: none;' href=UserHome.jsp>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Back</a><br>");
       p.print("</div>");
       p.print("<div class='row'>");
        p.print("<div class='col-lg-1'>");
       p.print("</div>");
       p.print("<div class='col-lg-10'><center>");
    p.print("<table border=1 style='border-collapse: collapse;'><tr>   <th>Order Id</th>  <th>Train no</th>  <th>User Email</th> <th>User name</th> <th>No OF Seats</th> <th>From Station</th> <th>To Station</th> <th>Total Fare</th> <th>QR Code</th> </thead>");
            while (rslt.next() ) {
               String id = rslt.getString(1);
              // p.print("<tr ><td>"+  rslt.getString(1)+"</td> <td>"+  rslt.getString(2)+"</td> <td>"+  rslt.getString(3)+"</td> <td>"+  rslt.getString(4)+"</td> <td>"+  rslt.getString(5)+"</td> <td>"+  rslt.getString(6)+"</td> <td>"+  rslt.getString(7)+"</td><td>"+  rslt.getString(8)+"</td><td>"+"</td></tr>");
                 p.print("<tr ><td>"+  rslt.getString(1)+"</td> <td>"+  rslt.getString(2)+"</td> <td>"+  rslt.getString(3)+"</td> <td>"+  rslt.getString(4)+"</td><td>"+  rslt.getString(5)+"</td><td>"+  rslt.getString(6)+"</td> <td>"+rslt.getString(7)+"</td><td>"+ rslt.getString(8)+"</td><td><form name='testform' action='qrcodegen.jsp'><input type=\"hidden\" name=\"id\" value=\" "+ rslt.getString(1) +" \"><input type=\"hidden\" name=\"tno\" value=\" "+ rslt.getString(2) +" \"><input type=\"hidden\" name=\"un\" value=\" "+ rslt.getString(4) +" \"><input type=\"hidden\" name=\"seat\" value=\" "+ rslt.getString(5) +" \"><input type=\"hidden\" name=\"amount\" value=\" "+ rslt.getString(8) +" \"><br/>\n" +
"<input type=\"submit\"></form>"+"</td> </tr>");
                
            }
       
      
            p.print("</table><br>");
 p.print("</div>");
       p.print("<div class='col-lg-1'>");
       p.print("</div>");
       
       
       
      
       p.print("</div>");
   
       p.println("</Body>");
       p.println("</html>");


        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

//     public String button() {
//    out.print("<html><head>\n" +
//"     
//"        <meta charset=\"UTF-8\">\n" +
//"        <meta name=\"viewport\" content=\"width=device-width,\n" +
//"                                       initial-scale=1.0\">\n" +
//"    </head>\n" +
//"    <body>\n" +
//"        <!-- Here we specify that the from data will be sent to \n" +
//"             getparam.jsp page using the action attribute  \n" +
//"        -->\n" +
//"        <form name=\"testForm\" action=\"qrcodegen.jsp\">\n" +
//"         <input type=\"submit\">\n" +
//"        </form>\n" +
//"    </body>\n" +
//"</html>");   
//        return button();
//    }
            }

