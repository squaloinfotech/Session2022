
package trainPack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class register extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
 System.out.println("Starting")         ;  
         out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet register</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet register at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }



    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            PrintWriter p  = response.getWriter();
            String Bname = request.getParameter("studentname");
            String email = request.getParameter("studentemail");
            String dob = request.getParameter("date");
            String sex = request.getParameter("gender");
            String pass  = request.getParameter("pass");
            String mob = request.getParameter("mob");
            String add  = request.getParameter("add");
            
            try{
                Class.forName("com.mysql.jdbc.Driver");
            
             Connection con;
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rail","root","");
                System.out.println("establish ");
               
            if (con == null) {
             
//            return false;
            }
            PreparedStatement psmt2;
            psmt2 = con.prepareStatement("select count(email) from login where email = ?");
            psmt2.setString(1,email);
            ResultSet rslt;
            int total = 0;
            rslt = psmt2.executeQuery();
            if(rslt.next())
            {
               total = rslt.getInt(1);
            }
            
                      if(total==0)
            {
            PreparedStatement psmt;
            System.out.print("bname"+Bname);
            psmt = con.prepareStatement("insert into user(name,email,dob,gender,mobile,addr) values (?,?,?,?,?,?)");  
            psmt.setString(1,Bname);
   
            psmt.setString(2,email);
            psmt.setString(3,dob);
            psmt.setString(4,sex);
            psmt.setString(5,mob);
            psmt.setString(6,add);
            
              
              
              int i=psmt.executeUpdate();  

              PreparedStatement psmt1;
            psmt1= con.prepareStatement("insert into login(email,password,name) values (?,?,?)");
            psmt1.setString(1,email);
            psmt1.setString(2,pass);
            psmt1.setString(3,Bname);
            int j=psmt1.executeUpdate();
            
                            if(i!=0 && j!=0)
       {
       p.println("<script>alert('registered Sucsessfully');window.location='index.jsp';</script>");
       }
       else
       {
       p.println("<script>alert('Sorry Fail to tegister ! try again');window.location='index.jsp';</script>");    
       }
            }
                    else
            {
         p.println("<script>alert('Fail to register..Email provided already registred with us');window.location='index.jsp';</script>");           
            }      


            }catch(Exception ex){
                ex.printStackTrace();
            }
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
