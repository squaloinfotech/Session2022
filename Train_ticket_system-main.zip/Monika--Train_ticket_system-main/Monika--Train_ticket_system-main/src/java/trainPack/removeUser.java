
package trainPack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class removeUser extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet removeUser</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet removeUser at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                                 PrintWriter out = response.getWriter();
       String em = request.getParameter("remove");
       out.print("Trying to remove user" +em);
               try {
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection con;
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rail","root","");
            
            if (con == null) {
//            return false;
            }


            PreparedStatement psmt;
            PreparedStatement psmt2;
            psmt = con.prepareStatement("delete from user where email = ?");
             
            psmt.setString(1,em);
//            p.println("okeyfdg");
            psmt2 = con.prepareStatement("delete from login where email = ?");
            psmt2.setString(1,em);
            response.setContentType("text/html;charset=UTF-8");
            int i = psmt.executeUpdate();
            int j = psmt2.executeUpdate();
            
            if (i!=0 && j!=0) {
            
                
  out.println("<script>alert('User has been removed from the database');window.location='showUser';</script>");
                
                
            } else {

                out.println("<script>alert('User not Found');window.location='showUser';</script>");
            }



        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
