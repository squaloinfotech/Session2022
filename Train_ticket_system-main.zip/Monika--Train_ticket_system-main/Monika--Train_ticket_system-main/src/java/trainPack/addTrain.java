
package trainPack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

public class addTrain extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet addTrain</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet addTrain at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                 PrintWriter p  = response.getWriter();
            String tname = request.getParameter("studentname");
            String tno = request.getParameter("studentemail");
            int rate = Integer.parseInt(request.getParameter("rate"));
            
            String date = request.getParameter("date");
            String froms = request.getParameter("froms");
            String tos  = request.getParameter("tos");
           int seat = Integer.parseInt(request.getParameter("seat"));
            try{
                Connection con;
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rail","root","");
               
            if (con == null) {
             
    p.println("<script>alert('Something Went Wrong !!');window.location='adminHome.jsp';</script>");
            }
            PreparedStatement psmt;
            psmt = con.prepareStatement("insert into train(trainno,trainname,rate,date,froms,tos,seats) values (?,?,?,?,?,?,?)");  
            
              psmt.setString(1,tno);
            psmt.setString(2,tname);
            psmt.setInt(3,rate);
            psmt.setString(4,date);
              psmt.setString(5,froms);
              psmt.setString(6,tos);
              psmt.setInt(7,seat);
            
            int i=psmt.executeUpdate();  
            
            
              
             if(i!=0)
       {
       p.println("<script>alert('Train added Sucsessfully');window.location='adminHome.jsp';</script>");
       }
       else
       {
       p.println("<script>alert('Sorry Fail to Add ! try again');window.location='adminHome.jsp';</script>");    
       }
            }catch(Exception ex){
                
            }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
