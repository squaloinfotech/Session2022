/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



function alertCardType(){
    var cardtype = document.getElementById("to").value
  
    var m = 'c';
    if(cardtype===m)
        {
           alert("You have selected Credit card to pay bills") ;
        }
        else
            {
           alert("You have selected Debit card to pay bills") ;     
            }
}

function paymentValidation(){
   var flag1 = true ;
   var flag2 = true ;
   var flag = false ;
   var c = document.getElementById("cn").value 
   var cv = document.getElementById("cvc").value 
   
   if(c === null || c==="")
       {
           alert("Please fill card number");
           flag1 = false;
       }
   else {
       var filter = /^[0-9]/;
       if (!filter.test(c))
           {
            alert("Card Number should be numeric only");
   flag1 = false;
            
           }
      else{
          if(c.length !== 12)
              {
                  alert("Card Number Not valid");flag1 = false;
              }
      }     
           
   }    
   
   if(cv === null || cv==="")
       {
           alert("Please fill cvc number");
           flag2 = false;
       }
   else {
       var filter = /^[0-9]/;
       if (!filter.test(cv))
           {
            alert("cvc Number should be numeric only");
   flag2 = false;
            
           }
      else{
          if(cv.length !== 3)
              {
                  alert("cvc Number Not valid");flag2 = false;
              }
      }     
           
   }    
   
   
   
   
   
   
       if(flag1 === true && flag2=== true){
          
           flag = true;
           
       }
     if(flag1 === true && flag2=== true){
          
           alert("booking Sucssefull !!");
           
       }
   
 return flag;
}
