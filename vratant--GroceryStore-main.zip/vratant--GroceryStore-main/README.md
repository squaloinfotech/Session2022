# vratant--GroceryStore
web based application using Django python

resources:
download python latest version (https://www.python.org/ftp/python/3.9.6/python-3.9.6-amd64.exe)
download VScode for development (https://code.visualstudio.com/sha/download?build=stable&os=win32-x64-user)
Download Postgres Database (https://www.enterprisedb.com/downloads/postgres-postgresql-downloads)
open cmd and write some commands:
- pip install django
- pip install Pillow
open project folder in VScode and open terminal ( located on the menu)
open terminal then write some of django code:
- python manage.py makemigrations
- python manage.py migrate
- python manage.py runserver
then go to browser and write 128.0.0.1:8000 ( localhost ).
