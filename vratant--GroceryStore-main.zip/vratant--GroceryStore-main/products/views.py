from django.shortcuts import render
from django.http import HttpResponse
from .models import Product
# Create your views here.



def index(request):
    veg = Product.objects.filter(category='vegetables')
    raw = Product.objects.filter(category='raw')
    fruits = Product.objects.filter(category= 'fruits')

    

    return render(request, 'index.html',{'veg':veg,'raw':raw,'fruit':fruits})

def offers(request):
    return render(request, 'offers.html')

def groceries(request):
    return render(request, 'groceries.html')

def products(request):
    return render(request, 'products.html')

def contact(request):
    return render(request, 'contact.html')

def about(request):
    return render(request, 'about.html')

def checkout(request):
    return render(request, 'checkout.html')

# def fruits(request):
#     return render(request,'fresh.html')

def pcare(request):
    return render(request, 'personalcare.html')

def register(request):
    return render(request, 'register.html')

def login(request):
    return render(request, 'login.html')

def forgot(request):
    return render(request, 'forgot.html')

def single(request):
    return render(request, 'single.html')

# Grocery

def raw(request):
    return render(request, 'raw.html')

def liquid(request):
    return render(request, 'liquid.html')


def packed(request):
    return render(request, 'packed.html')


def clothes(request):
    return render(request, 'clothes.html')

# Fresh 
def bevarages(request):
    return render(request, 'bevarages.html')

def fruits(request):
    return render(request, 'fruits.html')

def veg(request):
    return render(request, 'veg.html')

def flowers(request):
    return render(request, 'flowers.html')

def car(request):
    return render(request, 'car.html')