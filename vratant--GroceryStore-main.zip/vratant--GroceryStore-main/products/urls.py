from django.contrib import admin
from django.urls import path
from . import views
from .views import fruits

urlpatterns = [

    path('', views.index, name='index'),
    path('groceries/', views.groceries, name='groceries'),
    path('products/', views.products, name='products'),
    path('offers', views.offers, name='offers'),
    path('contact', views.contact, name='contact'),
    path('about/', views.about, name = 'about'),
    path('fruits/', views.fruits, name = 'fruits'),   
    path('checkout/', views.checkout, name= 'checkout'),
    path('pcare', views.pcare, name= 'pcare'),
    path('register', views.register, name= 'register'),
    path('login', views.login, name= 'login'),
    path('forgot', views.forgot, name= 'forgot'),
    path('single', views.single, name = 'single'), 
    # Grocery Tag
    path('raw', views.raw, name= 'raw'), 
    path('liquid', views.liquid, name= 'liquid'), 
    path('packed', views.packed, name= 'packed'), 
    path('clothes', views.liquid, name= 'clothes'), 
    # Fresh Tag
    path('fruits', views.fruits, name= 'fruits'), 
    path('veg', views.veg, name= 'veg'), 
    path('bevarages', views.bevarages, name= 'bevarages'),
    path('flowers', views.flowers, name= 'flowers'), 

    path('car/',views.car,name='car')
    
]


   